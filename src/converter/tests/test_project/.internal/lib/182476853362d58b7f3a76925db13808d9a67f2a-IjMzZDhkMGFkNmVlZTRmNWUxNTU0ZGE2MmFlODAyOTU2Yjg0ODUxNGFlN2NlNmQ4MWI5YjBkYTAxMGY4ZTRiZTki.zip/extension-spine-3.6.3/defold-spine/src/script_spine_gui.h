#ifndef DM_GAMESYS_SCRIPT_SPINE_GUI_H
#define DM_GAMESYS_SCRIPT_SPINE_GUI_H

namespace dmSpine
{
    void ScriptSpineGuiRegister(struct lua_State* L);
}

#endif // DM_GAMESYS_SCRIPT_SPINE_GUI_H
